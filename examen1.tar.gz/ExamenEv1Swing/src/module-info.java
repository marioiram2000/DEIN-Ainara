module ExamenEv1Swing {
	requires java.desktop;
	requires java.sql;
}